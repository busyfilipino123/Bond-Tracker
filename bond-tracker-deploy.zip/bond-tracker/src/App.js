import { useState, useEffect } from "react";

const CATEGORIES = [
  { id: "convo",     label: "Real Talk",   icon: "💬", points: 15, color: "#FF6B35", desc: "Meaningful conversations" },
  { id: "chores",    label: "Side by Side",icon: "🔧", points: 10, color: "#4ECDC4", desc: "Chores & tasks together"  },
  { id: "volunteer", label: "Give Back",   icon: "🤝", points: 25, color: "#FFE66D", desc: "Volunteering & service"   },
  { id: "adventure", label: "Adventure",   icon: "⚡", points: 20, color: "#A8E6CF", desc: "New experiences together" },
  { id: "teach",     label: "Wisdom",      icon: "📚", points: 15, color: "#FF8B94", desc: "Teaching & learning"      },
  { id: "tradition", label: "Tradition",   icon: "🔥", points: 20, color: "#B8B8FF", desc: "Rituals & recurring moments" },
];

const LEVELS = [
  { name: "Rookie",    min: 0,    max: 200,      color: "#9CA3AF" },
  { name: "Solid",     min: 200,  max: 500,      color: "#60A5FA" },
  { name: "Locked In", min: 500,  max: 1000,     color: "#34D399" },
  { name: "Legacy",    min: 1000, max: 2000,     color: "#F59E0B" },
  { name: "Legend",    min: 2000, max: Infinity,  color: "#EC4899" },
];

const BADGES = [
  { id: "first",     label: "First Step",     icon: "👶", desc: "Log your first activity",           check: (s) => s.logs.length >= 1         },
  { id: "streak3",   label: "3-Day Streak",   icon: "🔥", desc: "3 days in a row",                  check: (s) => s.streak >= 3              },
  { id: "streak7",   label: "Week Strong",    icon: "💪", desc: "7-day streak",                     check: (s) => s.streak >= 7              },
  { id: "volunteer", label: "Give Back",      icon: "🤝", desc: "Log 3 volunteer activities",        check: (s) => s.logs.filter(l => l.cat === "volunteer").length >= 3 },
  { id: "allcat",    label: "Well Rounded",   icon: "🌟", desc: "Log every category at least once", check: (s) => new Set(s.logs.map(l => l.cat)).size >= 6 },
  { id: "legend",    label: "Legend Status",  icon: "👑", desc: "Reach 2000 points",                check: (s) => s.totalPoints >= 2000      },
];

const DAILY_GOAL = 50;
const STORAGE_KEY = "bond_tracker_v1";

function getLevel(points) {
  return LEVELS.find(l => points >= l.min && points < l.max) || LEVELS[LEVELS.length - 1];
}

function getTodayStr() {
  return new Date().toDateString();
}

function getDayIndex() {
  return new Date().getDay();
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    totalPoints: 0,
    streak: 0,
    lastLogDate: null,
    logs: [],
    weeklyPoints: [0, 0, 0, 0, 0, 0, 0],
    weekStart: getTodayStr(),
  };
}

export default function App() {
  const [state, setState] = useState(loadState);
  const [view, setView] = useState("home");
  const [logging, setLogging] = useState(null);
  const [note, setNote] = useState("");
  const [toast, setToast] = useState(null);
  const [animPts, setAnimPts] = useState(null);
  const [newBadge, setNewBadge] = useState(null);

  // Persist to localStorage on every state change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const level = getLevel(state.totalPoints);
  const levelIdx = LEVELS.indexOf(level);
  const nextLevel = LEVELS[levelIdx + 1];
  const levelProgress = nextLevel
    ? ((state.totalPoints - level.min) / (nextLevel.min - level.min)) * 100
    : 100;

  const todayLogs = state.logs.filter(l => l.date === getTodayStr());
  const todayPoints = todayLogs.reduce((s, l) => s + l.points, 0);
  const dailyProgress = Math.min((todayPoints / DAILY_GOAL) * 100, 100);

  const earnedBadges = BADGES.filter(b => b.check(state));

  function showToast(msg, color) {
    setToast({ msg, color });
    setTimeout(() => setToast(null), 2800);
  }

  function logActivity(cat) {
    const pts = cat.points;
    const today = getTodayStr();

    setState(prev => {
      // Streak logic
      let newStreak = prev.streak;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      if (prev.lastLogDate !== today) {
        newStreak = prev.lastLogDate === yesterday.toDateString() ? prev.streak + 1 : 1;
      }

      // Weekly reset if needed (new week)
      const newWeekly = [...prev.weeklyPoints];
      newWeekly[getDayIndex()] = (newWeekly[getDayIndex()] || 0) + pts;

      const newState = {
        ...prev,
        totalPoints: prev.totalPoints + pts,
        streak: newStreak,
        lastLogDate: today,
        weeklyPoints: newWeekly,
        logs: [
          {
            id: Date.now(),
            cat: cat.id,
            label: cat.label,
            icon: cat.icon,
            points: pts,
            note: note.trim(),
            date: today,
            ts: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          },
          ...prev.logs,
        ].slice(0, 100),
      };

      // Check for newly earned badges
      const prevEarned = BADGES.filter(b => b.check(prev)).map(b => b.id);
      const newEarned = BADGES.filter(b => b.check(newState)).map(b => b.id);
      const justEarned = BADGES.find(b => !prevEarned.includes(b.id) && newEarned.includes(b.id));
      if (justEarned) setTimeout(() => setNewBadge(justEarned), 400);

      return newState;
    });

    setAnimPts(`+${pts}`);
    setTimeout(() => setAnimPts(null), 1200);
    showToast(`${cat.icon} +${pts} pts — ${cat.label}!`, cat.color);
    setLogging(null);
    setNote("");
  }

  const days = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
  const maxWeekly = Math.max(...state.weeklyPoints, 1);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0A0A0F",
      color: "#F0F0F5",
      fontFamily: "'DM Sans', system-ui, sans-serif",
      maxWidth: 480,
      margin: "0 auto",
      position: "relative",
    }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 0; }
        button { cursor: pointer; border: none; background: none; font-family: inherit; }
        textarea { font-family: inherit; }
        @keyframes fadeDown  { from { opacity:0; transform:translateX(-50%) translateY(-12px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }
        @keyframes floatUp   { 0% { opacity:1; transform:translateX(-50%) scale(1) translateY(0); } 100% { opacity:0; transform:translateX(-50%) scale(1.6) translateY(-80px); } }
        @keyframes badgePop  { 0% { opacity:0; transform:translate(-50%,-50%) scale(0.6); } 60% { transform:translate(-50%,-50%) scale(1.05); } 100% { opacity:1; transform:translate(-50%,-50%) scale(1); } }
        @keyframes glow      { 0%,100% { box-shadow: 0 0 20px #6358FF44; } 50% { box-shadow: 0 0 40px #6358FF88; } }
      `}</style>

      {/* Background glow */}
      <div style={{
        position: "fixed", top: -120, left: "50%", transform: "translateX(-50%)",
        width: 700, height: 500, borderRadius: "50%",
        background: "radial-gradient(ellipse, rgba(99,88,255,0.15) 0%, transparent 70%)",
        pointerEvents: "none", zIndex: 0,
      }} />

      {/* Toast */}
      {toast && (
        <div style={{
          position: "fixed", top: 18, left: "50%",
          background: toast.color, color: "#000",
          fontWeight: 700, fontSize: 13, padding: "10px 22px",
          borderRadius: 30, zIndex: 9999,
          boxShadow: `0 4px 30px ${toast.color}88`,
          animation: "fadeDown 0.3s ease", whiteSpace: "nowrap",
        }}>
          {toast.msg}
        </div>
      )}

      {/* Floating points */}
      {animPts && (
        <div style={{
          position: "fixed", top: "38%", left: "50%",
          fontSize: 52, fontWeight: 900, color: "#FFE66D",
          textShadow: "0 0 40px #FFE66D", zIndex: 9998,
          pointerEvents: "none", animation: "floatUp 1.2s ease forwards",
        }}>
          {animPts}
        </div>
      )}

      {/* Badge earned modal */}
      {newBadge && (
        <div
          onClick={() => setNewBadge(null)}
          style={{
            position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)",
            zIndex: 9990, display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <div style={{
            background: "#12121A", border: "1px solid #6358FF44", borderRadius: 24,
            padding: "36px 40px", textAlign: "center", maxWidth: 300,
            animation: "badgePop 0.4s ease forwards",
            boxShadow: "0 0 60px #6358FF44",
          }}>
            <div style={{ fontSize: 60 }}>{newBadge.icon}</div>
            <div style={{ fontSize: 11, letterSpacing: 3, color: "#6358FF", marginTop: 14, textTransform: "uppercase", fontFamily: "'Space Mono'" }}>Badge Unlocked</div>
            <div style={{ fontSize: 22, fontWeight: 900, marginTop: 6 }}>{newBadge.label}</div>
            <div style={{ fontSize: 12, color: "#666", marginTop: 6 }}>{newBadge.desc}</div>
            <button onClick={() => setNewBadge(null)} style={{
              marginTop: 20, padding: "10px 28px", background: "#6358FF",
              color: "#fff", borderRadius: 30, fontSize: 13, fontWeight: 700,
            }}>
              Let's Go 🔥
            </button>
          </div>
        </div>
      )}

      {/* ── HEADER ── */}
      <div style={{ padding: "28px 20px 0", position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: "#555", textTransform: "uppercase", fontFamily: "'Space Mono'" }}>Father × Son</div>
            <div style={{ fontSize: 28, fontWeight: 900, lineHeight: 1.1, marginTop: 2 }}>Bond Tracker</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{
              background: `${level.color}22`, border: `1px solid ${level.color}55`,
              borderRadius: 20, padding: "6px 14px",
              fontSize: 11, fontWeight: 700, color: level.color, fontFamily: "'Space Mono'",
            }}>
              {level.name}
            </div>
            <div style={{ fontSize: 10, color: "#555", marginTop: 4, fontFamily: "'Space Mono'" }}>
              {state.totalPoints.toLocaleString()} pts total
            </div>
          </div>
        </div>

        {/* Level progress */}
        <div style={{ marginTop: 16, background: "#1A1A22", borderRadius: 8, height: 6, overflow: "hidden" }}>
          <div style={{
            height: "100%", width: `${levelProgress}%`, borderRadius: 8,
            background: `linear-gradient(90deg, ${level.color}, ${level.color}BB)`,
            boxShadow: `0 0 14px ${level.color}88`,
            transition: "width 0.7s cubic-bezier(.4,0,.2,1)",
          }} />
        </div>
        {nextLevel && (
          <div style={{ fontSize: 9, color: "#444", marginTop: 4, textAlign: "right", fontFamily: "'Space Mono'" }}>
            {nextLevel.min - state.totalPoints} pts → {nextLevel.name}
          </div>
        )}
      </div>

      {/* ── STATS ROW ── */}
      <div style={{ display: "flex", gap: 10, padding: "16px 20px 0", position: "relative", zIndex: 1 }}>
        {[
          { label: "Streak",     value: state.streak > 0 ? `${state.streak} 🔥` : "0",  sub: "days"       },
          { label: "Today",      value: todayPoints,                                       sub: `/ ${DAILY_GOAL} pts` },
          { label: "Activities", value: state.logs.length,                                 sub: "logged"     },
        ].map(s => (
          <div key={s.label} style={{
            flex: 1, background: "#12121A", borderRadius: 14, padding: "12px 8px",
            border: "1px solid #1E1E28", textAlign: "center",
          }}>
            <div style={{ fontSize: 18, fontWeight: 900, fontFamily: "'Space Mono'" }}>{s.value}</div>
            <div style={{ fontSize: 9, color: "#555", textTransform: "uppercase", letterSpacing: 1, marginTop: 2 }}>{s.label}</div>
            <div style={{ fontSize: 9, color: "#3A3A4A", marginTop: 1 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* ── DAILY MISSION ── */}
      <div style={{ padding: "12px 20px 0", position: "relative", zIndex: 1 }}>
        <div style={{
          background: "#12121A", borderRadius: 16, padding: "14px 16px",
          border: dailyProgress >= 100 ? "1px solid #FFE66D33" : "1px solid #1E1E28",
          boxShadow: dailyProgress >= 100 ? "0 0 24px #FFE66D18" : "none",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ fontSize: 12, fontWeight: 700 }}>
              {dailyProgress >= 100 ? "🏆 Daily Goal Crushed!" : "⚡ Daily Mission"}
            </span>
            <span style={{ fontSize: 11, color: "#666", fontFamily: "'Space Mono'" }}>{Math.round(dailyProgress)}%</span>
          </div>
          <div style={{ background: "#1A1A22", borderRadius: 6, height: 8, overflow: "hidden" }}>
            <div style={{
              height: "100%", width: `${dailyProgress}%`, borderRadius: 6,
              background: dailyProgress >= 100
                ? "linear-gradient(90deg, #FFE66D, #FF6B35)"
                : "linear-gradient(90deg, #6358FF, #A78BFA)",
              boxShadow: dailyProgress >= 100 ? "0 0 18px #FFE66D77" : "0 0 12px #6358FF77",
              transition: "width 0.6s ease",
            }} />
          </div>
          <div style={{ fontSize: 10, color: "#3A3A4A", marginTop: 6 }}>
            {todayPoints} of {DAILY_GOAL} points today
          </div>
        </div>
      </div>

      {/* ── NAV TABS ── */}
      <div style={{
        display: "flex", margin: "14px 20px 0",
        background: "#0E0E16", borderRadius: 12, padding: 4,
        border: "1px solid #1E1E28", position: "relative", zIndex: 1,
      }}>
        {[["home","Log"], ["chart","Week"], ["badges","Badges"], ["feed","History"]].map(([v, label]) => (
          <button key={v} onClick={() => setView(v)} style={{
            flex: 1, padding: "9px 0", borderRadius: 9,
            fontSize: 11, fontWeight: 700,
            background: view === v ? "#1E1E2E" : "transparent",
            color: view === v ? "#F0F0F5" : "#444",
            border: view === v ? "1px solid #2A2A3A" : "1px solid transparent",
            transition: "all 0.2s",
          }}>
            {label}
          </button>
        ))}
      </div>

      {/* ── CONTENT ── */}
      <div style={{ padding: "16px 20px 100px", position: "relative", zIndex: 1 }}>

        {/* LOG VIEW */}
        {view === "home" && (
          <div>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#444", textTransform: "uppercase", marginBottom: 12, fontFamily: "'Space Mono'" }}>
              What did you do together?
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setLogging(logging?.id === cat.id ? null : cat)}
                  style={{
                    background: logging?.id === cat.id ? `${cat.color}18` : "#12121A",
                    border: `1px solid ${logging?.id === cat.id ? cat.color : "#1E1E28"}`,
                    borderRadius: 16, padding: "16px 14px", textAlign: "left",
                    transition: "all 0.2s",
                    transform: logging?.id === cat.id ? "scale(0.97)" : "scale(1)",
                  }}
                >
                  <div style={{ fontSize: 28, marginBottom: 6 }}>{cat.icon}</div>
                  <div style={{ fontSize: 13, fontWeight: 700 }}>{cat.label}</div>
                  <div style={{ fontSize: 10, color: "#555", marginTop: 2, lineHeight: 1.4 }}>{cat.desc}</div>
                  <div style={{
                    display: "inline-block", marginTop: 8,
                    background: `${cat.color}18`, color: cat.color,
                    fontSize: 10, fontWeight: 700, padding: "3px 10px",
                    borderRadius: 20, fontFamily: "'Space Mono'",
                  }}>
                    +{cat.points} pts
                  </div>
                </button>
              ))}
            </div>

            {/* Log panel */}
            {logging && (
              <div style={{
                marginTop: 14, background: "#12121A", borderRadius: 16, padding: 16,
                border: `1px solid ${logging.color}44`,
                boxShadow: `0 0 40px ${logging.color}18`,
              }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: logging.color, marginBottom: 10 }}>
                  {logging.icon} Logging: {logging.label}
                </div>
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  placeholder="Add a note… what happened? (optional)"
                  style={{
                    width: "100%", background: "#0A0A0F", border: "1px solid #2A2A35",
                    borderRadius: 10, color: "#F0F0F5", fontSize: 13, padding: "10px 12px",
                    resize: "none", height: 72, outline: "none",
                  }}
                />
                <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                  <button
                    onClick={() => { setLogging(null); setNote(""); }}
                    style={{
                      flex: 1, padding: "12px 0", borderRadius: 10, fontSize: 13, fontWeight: 700,
                      background: "#1A1A22", color: "#555", border: "1px solid #2A2A35",
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => logActivity(logging)}
                    style={{
                      flex: 2, padding: "12px 0", borderRadius: 10, fontSize: 13, fontWeight: 700,
                      background: `linear-gradient(135deg, ${logging.color}, ${logging.color}BB)`,
                      color: "#000", boxShadow: `0 4px 24px ${logging.color}55`,
                    }}
                  >
                    Log +{logging.points} pts ✓
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* WEEK VIEW */}
        {view === "chart" && (
          <div>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#444", textTransform: "uppercase", marginBottom: 14, fontFamily: "'Space Mono'" }}>This Week</div>
            <div style={{ background: "#12121A", borderRadius: 16, padding: 20, border: "1px solid #1E1E28" }}>
              <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 130 }}>
                {days.map((d, i) => {
                  const h = Math.max((state.weeklyPoints[i] / maxWeekly) * 100, 3);
                  const isToday = i === getDayIndex();
                  return (
                    <div key={d} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                      <div style={{ fontSize: 9, color: "#444", fontFamily: "'Space Mono'" }}>
                        {state.weeklyPoints[i] > 0 ? state.weeklyPoints[i] : ""}
                      </div>
                      <div style={{
                        width: "100%", height: `${h}%`, borderRadius: 6,
                        background: isToday
                          ? "linear-gradient(180deg, #6358FF, #A78BFA)"
                          : state.weeklyPoints[i] > 0 ? "#2A2A3A" : "#161620",
                        boxShadow: isToday ? "0 0 16px #6358FF88" : "none",
                        transition: "height 0.5s ease", minHeight: 4,
                      }} />
                      <div style={{ fontSize: 9, color: isToday ? "#A78BFA" : "#444", fontWeight: isToday ? 700 : 400 }}>{d}</div>
                    </div>
                  );
                })}
              </div>

              <div style={{ marginTop: 20, paddingTop: 16, borderTop: "1px solid #1A1A22" }}>
                <div style={{ fontSize: 11, color: "#555", marginBottom: 12 }}>Points by category</div>
                {CATEGORIES.map(cat => {
                  const catPts = state.logs.filter(l => l.cat === cat.id).reduce((s, l) => s + l.points, 0);
                  if (!catPts) return null;
                  const pct = Math.min((catPts / Math.max(state.totalPoints, 1)) * 100, 100);
                  return (
                    <div key={cat.id} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                      <span style={{ fontSize: 16, width: 22 }}>{cat.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                          <span style={{ fontSize: 11, fontWeight: 600 }}>{cat.label}</span>
                          <span style={{ fontSize: 10, color: cat.color, fontFamily: "'Space Mono'" }}>{catPts} pts</span>
                        </div>
                        <div style={{ background: "#1A1A22", borderRadius: 4, height: 4 }}>
                          <div style={{
                            width: `${pct}%`, height: "100%", background: cat.color,
                            borderRadius: 4, transition: "width 0.6s ease",
                          }} />
                        </div>
                      </div>
                    </div>
                  );
                })}
                {state.totalPoints === 0 && (
                  <div style={{ fontSize: 12, color: "#333", textAlign: "center", padding: "20px 0" }}>
                    Log activities to see your breakdown
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* BADGES VIEW */}
        {view === "badges" && (
          <div>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#444", textTransform: "uppercase", marginBottom: 14, fontFamily: "'Space Mono'" }}>
              {earnedBadges.length} / {BADGES.length} Badges Earned
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {BADGES.map(b => {
                const earned = b.check(state);
                return (
                  <div key={b.id} style={{
                    background: earned ? "#12121A" : "#0C0C12",
                    border: `1px solid ${earned ? "#2A2A3A" : "#161620"}`,
                    borderRadius: 16, padding: "16px 14px", textAlign: "center",
                    opacity: earned ? 1 : 0.45,
                  }}>
                    <div style={{ fontSize: 32, filter: earned ? "none" : "grayscale(1)" }}>{b.icon}</div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginTop: 8 }}>{b.label}</div>
                    <div style={{ fontSize: 10, color: "#555", marginTop: 4, lineHeight: 1.4 }}>{b.desc}</div>
                    {earned && (
                      <div style={{
                        display: "inline-block", marginTop: 8,
                        background: "#34D39922", color: "#34D399",
                        fontSize: 9, fontWeight: 700, padding: "3px 10px",
                        borderRadius: 20, fontFamily: "'Space Mono'",
                      }}>
                        ✓ EARNED
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* HISTORY VIEW */}
        {view === "feed" && (
          <div>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#444", textTransform: "uppercase", marginBottom: 14, fontFamily: "'Space Mono'" }}>Activity Log</div>
            {state.logs.length === 0 ? (
              <div style={{
                background: "#12121A", borderRadius: 16, padding: 40,
                border: "1px solid #1E1E28", textAlign: "center",
              }}>
                <div style={{ fontSize: 44, marginBottom: 12 }}>👋</div>
                <div style={{ fontSize: 14, color: "#555" }}>Your story starts with the first log.</div>
                <button onClick={() => setView("home")} style={{
                  marginTop: 16, padding: "11px 26px", background: "#6358FF",
                  color: "#fff", borderRadius: 30, fontSize: 13, fontWeight: 700,
                  boxShadow: "0 4px 20px #6358FF55",
                }}>
                  Log First Activity
                </button>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {state.logs.map(log => {
                  const cat = CATEGORIES.find(c => c.id === log.cat);
                  return (
                    <div key={log.id} style={{
                      background: "#12121A", borderRadius: 14, padding: "13px 14px",
                      border: "1px solid #1A1A24",
                      display: "flex", alignItems: "center", gap: 12,
                    }}>
                      <div style={{
                        width: 44, height: 44, borderRadius: 12, flexShrink: 0,
                        background: `${cat?.color}18`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 22,
                      }}>
                        {log.icon}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 700 }}>{log.label}</div>
                        {log.note && (
                          <div style={{ fontSize: 11, color: "#555", marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {log.note}
                          </div>
                        )}
                        <div style={{ fontSize: 10, color: "#333", marginTop: 3 }}>{log.date} · {log.ts}</div>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 900, color: cat?.color, fontFamily: "'Space Mono'", flexShrink: 0 }}>
                        +{log.points}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Streak footer hint */}
      {view === "home" && !logging && (
        <div style={{
          position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)",
          width: "100%", maxWidth: 480, padding: "12px 20px 24px",
          background: "linear-gradient(to top, #0A0A0F 70%, transparent)",
          textAlign: "center", zIndex: 2,
        }}>
          <div style={{ fontSize: 10, color: "#333", fontFamily: "'Space Mono'", letterSpacing: 1 }}>
            {state.streak > 0 ? `🔥 ${state.streak}-day streak — don't break it` : "tap a category to log your first activity"}
          </div>
        </div>
      )}
    </div>
  );
}
